مشروع SAAD SCADA Monitor للأندرويد — Android Studio

هذه حزمة مشروع Android أصلية (WebView APK wrapper) تحتوي واجهة SCADA التجريبية داخل التطبيق، وتعمل دون إنترنت بعد تثبيتها.

طريقة استخراج APK:
1) ثبّت Android Studio على الكمبيوتر.
2) فك ضغط SAAD_SCADA_Android_Studio.zip.
3) افتح Android Studio ثم Open واختر مجلد SAAD_SCADA_Android_Studio.
4) انتظر Gradle Sync واكتمال تنزيل Android SDK 35 ومكونات Gradle عند الطلب.
5) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
6) بعد نجاح البناء اضغط Locate، وستجد الملف عادةً:
   app/build/outputs/apk/debug/app-debug.apk
7) انقل app-debug.apk إلى الهاتف وثبّته. قد تحتاج السماح بالتثبيت من هذا المصدر.

ملاحظات مهمة:
- هذه نسخة تطبيق Android بواجهة محلية وقراءات Demo فقط.
- لا يوجد اتصال PLC أو DCS في هذه النسخة.
- لا تستخدمها للتشغيل أو التحكم بمعدات المحطة.
- الربط الفعلي يحتاج مواصفات PLC والبروتوكول وخريطة Tags وتصميم أمن شبكة OT.
- يتطلب البناء اتصال إنترنت أول مرة لتنزيل Gradle/Android SDK إن لم تكن مثبتة.
